﻿// SoftSensor_BP.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "BPnet.h"

int main()
{
	BpNet testNet;

	// 学习样本
	
	vector<double> samplein[371];
	vector<double> sampleout[371];
	
	//sample sampleInOut;
	//创建一个变量，把txt文件中的数据读出来，然后将每行分配到一个个的vector中
	vector<vector<double>>  sample_devide1;//输入
	vector<vector<double>>  sample_devide2;//输出
	for (int i = 0; i < 371; i++)
	{
		testNet.txt_to_vectordouble(sample_devide1, "E:\\CppCodePractise\\soft_sensor\\train_in.txt");
	}
	cout << "训练数据的输入部分读取完毕:" << endl;
		//分配数据，这是一个二维数组
	for (int m = 0; m < 371; m++)
	{
		for (int n = 0; n < sample_devide1[m].size(); n++)
		{
			samplein[m].push_back(sample_devide1[m][n]);
		}
	}
	cout << "训练数据的输入部分整理完毕:" << endl;

	for (int i = 0; i < 371; i++)
	{
		testNet.txt_to_vectordouble(sample_devide2, "E:\\CppCodePractise\\soft_sensor\\train_out.txt");
	}
	
	cout << "训练数据的输出部分读取完毕:" << endl;
		//分配数据
	for (int m = 0; m < 371; m++)
	{
		for (int n = 0; n < sample_devide2[m].size(); n++)
		{
			sampleout[m].push_back(sample_devide2[m][n]);
		}
	}
	cout << "训练数据的输出部分处理完毕:" << endl;
	sample sampleInOut[371];
	//再把网络的输入和输出分开
	for (int i = 0; i < 371; i++)
	{
		sampleInOut[i].in = samplein[i];
		sampleInOut[i].out = sampleout[i];
	}

	cout << "综合数据处理完毕:" << endl;

	vector<sample> sampleGroup(sampleInOut, sampleInOut + 371);
	//输入到训练模型中
	testNet.training(sampleGroup, 0.01);

	// ------------------> 测试数据 <-------------------------------
	
	vector<double> testin[297];
	
	vector<vector<double>>  sample_devide3;//输入
	
	for (int i = 0; i < 297; i++)
	{
		testNet.txt_to_vectordouble(sample_devide3, "E:\\CppCodePractise\\soft_sensor\\test_in.txt");
	}
	cout << "测试数据的输入部分读取完毕:" << endl;
		//分配数据
	for ( int m = 0;m<371;m++)
	{
		for (int n = 0; n<sample_devide3[m].size();n++)
		{
			testin[m].push_back(sample_devide3[m][n]);
		}
	}
	cout << "测试数据的输入部分读取完毕:" << endl;

	sample testInOut[297];
	for (int i = 0; i < 297; i++)
	{
		testInOut[i].in = testin[i];
	}

	cout << "测试数据整理完毕:" << endl;
	vector<sample> testGroup(testInOut, testInOut + 297);
	// 预测测试数据，并输出结果
	testNet.predict(testGroup);

	for (int i = 0; i < testGroup.size(); i++)
	{
		for (int j = 0; j < testGroup[i].in.size(); j++) cout << testGroup[i].in[j] << "\t";
		cout << "-- 预测 :";
		for (int j = 0; j < testGroup[i].out.size(); j++) cout << testGroup[i].out[j] << "\t";
		cout << endl;
	}

	system("暂停");
	return 0;
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
